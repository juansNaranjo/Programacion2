
package ejerciciouno;

import java.util.Scanner;
import static javax.management.Query.gt;

/**
 *
 * @author juanpro
 */
public class EjercicioUno {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        int a,b,c; 
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Primer Número: ");
        a=teclado.nextInt();
        System.out.println("Segundo Número: ");
        b=teclado.nextInt();
        System.out.println("Tercer Número: ");
        c=teclado.nextInt();
       
        System.out.println("Los números ordenados de mayor a menor son:");  
        if(a>b){
            if (a>c) {
                System.out.println("El numero mayor es: " +a);
            } else{
                System.out.println("El número mayor es: "+c);
            }
            
        } else if (b>c){
            System.out.println("El número mayor es: "+b);
    } else {
            System.out.println("El numero mayor es: "+c);
        }
      
        
        
    }
    
}
