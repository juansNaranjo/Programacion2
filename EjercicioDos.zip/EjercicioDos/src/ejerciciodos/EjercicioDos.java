
package ejerciciodos;

import java.util.Scanner;

public class EjercicioDos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num, invertir =0, resto;
        Scanner scan = new Scanner(System.in);
        System.out.println("NUmero para la inversión: ");
        System.out.println("Introduce un número: ");
        num = scan.nextInt();
        
        while (num > 0) {            
            resto = num % 10;
            invertir = invertir*10 + resto;
            num /=10;
        }
        System.out.println("número invertido es: "+ invertir);
    
    }
    
}
