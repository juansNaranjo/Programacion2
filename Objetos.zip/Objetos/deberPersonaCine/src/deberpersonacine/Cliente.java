

package deberpersonacine;

import java.util.Date;

/**
 *
 * @author juanpro
 */
public class Cliente {
    private Persona persona;
    private Byte formaPagoCliente;
    private Date fechaPagoCliente;

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public Byte getFormaPagoCliente() {
        return formaPagoCliente;
    }

    public void setFormaPagoCliente(Byte formaPagoCliente) {
        this.formaPagoCliente = formaPagoCliente;
    }

    public Date getFechaPagoCliente() {
        return fechaPagoCliente;
    }

    public void setFechaPagoCliente(Date fechaPagoCliente) {
        this.fechaPagoCliente = fechaPagoCliente;
    }
    
    
}
