
package deberpersonacine;

import com.sun.xml.internal.ws.api.ha.StickyFeature;
import java.util.Date;

/**
 *
 * @author juanpro
 */
public class Cajero {
    private Persona persona;
    private int turnocajero;
    private String nombreSupervisor;
    private Date fechaTurnoCajero;

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public int getTurnocajero() {
        return turnocajero;
    }

    public void setTurnocajero(int turnocajero) {
        this.turnocajero = turnocajero;
    }

    public String getNombreSupervisor() {
        return nombreSupervisor;
    }

    public void setNombreSupervisor(String nombreSupervisor) {
        this.nombreSupervisor = nombreSupervisor;
    }

    public Date getFechaTurnoCajero() {
        return fechaTurnoCajero;
    }

    public void setFechaTurnoCajero(Date fechaTurnoCajero) {
        this.fechaTurnoCajero = fechaTurnoCajero;
    }
    
    
}
