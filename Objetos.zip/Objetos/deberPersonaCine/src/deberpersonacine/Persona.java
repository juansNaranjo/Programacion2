
package deberpersonacine;

/**
 *
 * @author juanpro
 */
public class Persona {
    private String nombrePersona;
    private String apellidoPersona;
    private Integer identificacionPersona;
    private Integer celularPersona;
    private String emailPersona;
    private String direccionPersona;

    public String getNombrePersona() {
        return nombrePersona;
    }

    public void setNombrePersona(String nombrePersona) {
        this.nombrePersona = nombrePersona;
    }

    public String getApellidoPersona() {
        return apellidoPersona;
    }

    public void setApellidoPersona(String apellidoPersona) {
        this.apellidoPersona = apellidoPersona;
    }

    public Integer getIdentificacionPersona() {
        return identificacionPersona;
    }

    public void setIdentificacionPersona(Integer identificacionPersona) {
        this.identificacionPersona = identificacionPersona;
    }

    public Integer getCelularPersona() {
        return celularPersona;
    }

    public void setCelularPersona(Integer celularPersona) {
        this.celularPersona = celularPersona;
    }

    public String getEmailPersona() {
        return emailPersona;
    }

    public void setEmailPersona(String emailPersona) {
        this.emailPersona = emailPersona;
    }

    public String getDireccionPersona() {
        return direccionPersona;
    }

    public void setDireccionPersona(String direccionPersona) {
        this.direccionPersona = direccionPersona;
    }
    
    
}
