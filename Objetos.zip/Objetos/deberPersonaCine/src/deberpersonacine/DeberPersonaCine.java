
package deberpersonacine;

/**
 *
 * @author juanpro
 */
public class DeberPersonaCine {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cajero cajeros = new Cajero();
        cajeros.setNombreSupervisor("Juan Naranjo");
        System.out.println("prueba de Persona " +cajeros.getNombreSupervisor());
    }
    
}
